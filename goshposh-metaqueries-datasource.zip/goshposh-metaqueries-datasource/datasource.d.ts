declare var MetaQueriesDatasource: any;
export {MetaQueriesDatasource};

