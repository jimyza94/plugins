var datasource_1 = require('./datasource');
exports.Datasource = datasource_1.MetaQueriesDatasource;
var query_ctrl_1 = require('./query_ctrl');
exports.QueryCtrl = query_ctrl_1.MetaQueriesQueryCtrl;
var config_ctrl_1 = require('./config_ctrl');
exports.ConfigCtrl = config_ctrl_1.MetaQueriesConfigCtrl;
//# sourceMappingURL=module.js.map