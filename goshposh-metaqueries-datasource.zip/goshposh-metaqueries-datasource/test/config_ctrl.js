///<reference path="../headers/common.d.ts" />
var MetaQueriesConfigCtrl = (function () {
    function MetaQueriesConfigCtrl() {
    }
    MetaQueriesConfigCtrl.templateUrl = 'partials/config.html';
    return MetaQueriesConfigCtrl;
})();
exports.MetaQueriesConfigCtrl = MetaQueriesConfigCtrl;
//# sourceMappingURL=config_ctrl.js.map