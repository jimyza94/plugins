///<reference path="../headers/common.d.ts" />

import angular from 'angular';
import _ from 'lodash';

export class MetaQueriesConfigCtrl {
  static templateUrl = 'partials/config.html';
  current: any;
}
