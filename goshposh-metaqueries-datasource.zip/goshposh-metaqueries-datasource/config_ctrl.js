///<reference path="../headers/common.d.ts" />
System.register([], function(exports_1) {
    var MetaQueriesConfigCtrl;
    return {
        setters:[],
        execute: function() {
            MetaQueriesConfigCtrl = (function () {
                function MetaQueriesConfigCtrl() {
                }
                MetaQueriesConfigCtrl.templateUrl = 'partials/config.html';
                return MetaQueriesConfigCtrl;
            })();
            exports_1("MetaQueriesConfigCtrl", MetaQueriesConfigCtrl);
        }
    }
});
//# sourceMappingURL=config_ctrl.js.map