/// <reference path="../headers/common.d.ts" />
export declare class MetaQueriesConfigCtrl {
    static templateUrl: string;
    current: any;
}
